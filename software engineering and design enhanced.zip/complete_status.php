<?php

if (isset($_GET['rid'])) {

	$id = $_GET['rid'];

	$connect = mysqli_connect("localhost","root","","work");
     $query = "UPDATE add_task SET status = 'Complete' WHERE id = '$id' ";
    $query_result = mysqli_query($connect,$query);
    if ($query_result == 1) {
    	header("location:task_data.php");
    	exit;
    }
}







?>