<?php

$connection = mysqli_connect("localhost","root","","work");
$id = $_GET['rid'];
$query = "DELETE FROM add_task WHERE id = $id";
$query_result = mysqli_query($connection,$query);
if ($query_result) {
	echo "deleted successfully"; 
	header('location:task_data.php');
	exit;
}

?>  