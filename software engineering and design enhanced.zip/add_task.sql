-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2024 at 08:32 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `work`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_task`
--

CREATE TABLE `add_task` (
  `id` int(11) NOT NULL,
  `task` varchar(255) NOT NULL,
  `priority` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_task`
--

INSERT INTO `add_task` (`id`, `task`, `priority`, `status`, `created_at`) VALUES
(10, 'LOGIN FORM', 'php', 'Pending', '2024-08-10 21:57:02'),
(11, 'create form', 'css,html', 'Pending', '2024-08-10 21:57:13'),
(12, 'create form', 'css,html', 'Complete', '2024-08-10 22:18:36'),
(13, 'create form', 'php', 'Complete', '2024-08-10 22:43:22'),
(14, 'create form', 'css,html', 'Complete', '2024-08-10 23:12:11'),
(15, 'create form', 'php', 'Pending', '2024-08-10 23:12:15'),
(16, 'ssa', 'dc', 'Complete', '2024-08-10 23:12:20'),
(17, 'ssa', 'css,html', 'Pending', '2024-08-10 23:12:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_task`
--
ALTER TABLE `add_task`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_task`
--
ALTER TABLE `add_task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
